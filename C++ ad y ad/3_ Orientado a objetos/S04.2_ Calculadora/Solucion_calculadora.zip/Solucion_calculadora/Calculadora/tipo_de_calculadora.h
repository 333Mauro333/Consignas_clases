#pragma once

enum class TIPO_DE_CALCULADORA { COMUN, CIENTIFICA };
