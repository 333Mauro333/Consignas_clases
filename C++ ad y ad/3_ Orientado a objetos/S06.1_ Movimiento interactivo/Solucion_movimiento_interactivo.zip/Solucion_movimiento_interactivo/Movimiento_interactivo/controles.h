#pragma once

struct CONTROLES
{
	int izquierda;
	int derecha;
	int arriba;
	int abajo;
};
