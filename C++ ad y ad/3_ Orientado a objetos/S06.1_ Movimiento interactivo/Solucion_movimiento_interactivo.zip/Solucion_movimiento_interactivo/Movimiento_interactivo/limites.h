#pragma once

struct LIMITES
{
	int superior;
	int inferior;
	int izquierdo;
	int derecho;
};
