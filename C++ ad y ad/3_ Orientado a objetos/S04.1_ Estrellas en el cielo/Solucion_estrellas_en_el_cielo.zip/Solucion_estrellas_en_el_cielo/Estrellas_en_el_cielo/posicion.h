#pragma once

struct POSICION
{
	int x;
	int y;
};
