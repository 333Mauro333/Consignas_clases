#pragma once

enum class OPCION_DEL_MENU { JUGAR = 1, OPCIONES, AYUDA, CREDITOS, SALIR };
