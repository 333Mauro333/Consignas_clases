﻿
namespace La_observacion
{
	class Nube
	{
		string color;


		public Nube(string color)
		{
			this.color = color;
		}


		public string GetColor()
		{
			return color;
		}
	}
}
