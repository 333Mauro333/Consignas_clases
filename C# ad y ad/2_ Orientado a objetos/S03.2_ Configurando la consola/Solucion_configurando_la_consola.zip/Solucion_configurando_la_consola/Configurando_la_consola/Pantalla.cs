﻿
namespace Configurando_la_consola
{
	enum Pantalla { MenuPrincipal, ColorDelTexto = 2, ColorDelFondo, CambiarTitulo, ReaccionDeTeclas, ConfirmacionDeSalida };
}
