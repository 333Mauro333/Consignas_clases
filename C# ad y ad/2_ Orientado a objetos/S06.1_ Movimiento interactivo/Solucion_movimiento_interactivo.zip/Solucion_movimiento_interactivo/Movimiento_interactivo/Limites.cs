﻿
namespace Movimiento_interactivo
{
	struct Limites
	{
		public int superior;
		public int inferior;
		public int izquierdo;
		public int derecho;
	}
}
