﻿using System;


namespace Movimiento_interactivo
{
	struct Controles
	{
		public ConsoleKey arriba;
		public ConsoleKey abajo;
		public ConsoleKey izquierda;
		public ConsoleKey derecha;
	}
}
