﻿
namespace Movimiento_interactivo
{
	struct Posicion
	{
		public int x;
		public int y;
	}
}
