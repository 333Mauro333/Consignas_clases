﻿
namespace Consolas
{
	enum Pantalla { MenuPrincipal, ConectarAConsola, CambiarVolumen, CambiarBrillo };
}
