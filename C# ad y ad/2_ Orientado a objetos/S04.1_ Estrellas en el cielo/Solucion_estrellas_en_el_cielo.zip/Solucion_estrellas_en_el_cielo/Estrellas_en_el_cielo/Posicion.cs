﻿
namespace Estrellas_en_el_cielo
{
	struct Posicion
	{
		public int x;
		public int y;
	}
}
