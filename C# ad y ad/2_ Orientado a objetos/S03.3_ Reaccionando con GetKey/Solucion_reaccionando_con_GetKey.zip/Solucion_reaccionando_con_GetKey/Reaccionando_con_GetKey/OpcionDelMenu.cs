﻿
namespace Reaccionando_con_GetKey
{
	enum OpcionDelMenu { Jugar = 1, Opciones, Ayuda, Creditos, Salir }
}
