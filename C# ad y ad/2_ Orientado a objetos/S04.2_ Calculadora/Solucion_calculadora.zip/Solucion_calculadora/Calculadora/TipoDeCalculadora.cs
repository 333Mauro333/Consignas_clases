﻿
namespace Calculadora
{
	enum TipoDeCalculadora { Comun, Cientifica }
}
