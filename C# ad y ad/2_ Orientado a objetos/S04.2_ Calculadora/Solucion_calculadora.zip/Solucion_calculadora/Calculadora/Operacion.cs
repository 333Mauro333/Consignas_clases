﻿
namespace Calculadora
{
	enum Operacion { Suma = 1, Resta, Multiplicacion, Division, Potencia, Raiz };
}
