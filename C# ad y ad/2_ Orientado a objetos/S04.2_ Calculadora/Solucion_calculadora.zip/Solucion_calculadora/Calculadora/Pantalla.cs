﻿
namespace Calculadora
{
	enum Pantalla { MenuPrincipal, MenuComun, MenuCientifica, Estadisticas }
}
